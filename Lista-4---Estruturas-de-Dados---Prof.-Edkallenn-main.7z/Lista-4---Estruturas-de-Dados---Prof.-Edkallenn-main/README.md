
**Autor : Iury Mendonça Freire de França**
**Data : 05/06/2024**

1. **Sistema de Gerenciamento de Livros de Biblioteca: usando o algoritmo “quicksort”**

2.  **Pilha de Números Reais:**

3.  **Gerenciador de Perfil de Saúde:**

4.  **Classificação por Seleção:**

5.  **Gerenciador de Pilha de Processos:**

6.  **Lista de Compras:**

7.  **Sistema de Gerenciamento de Atendimento para Clínica Médica:**

